# -*- coding: utf-8 -*-

'''Entry point to all things to avoid circular imports.'''
from app import app, freezer, pages
from views import *
