title: Lebowski Ipsum
date: 2013-07-15 12:00:00

Lebowski ipsum i didn't blame anyone for the loss of my legs, some chinaman in Korea took them from me but I went out and achieved anyway. Dolor sit amet, consectetur adipiscing elit. I'll tell you who I am! I'm the guy who's gonna KICK YOUR PHONY GOLDBRICKING ASS! Praesent ac magna justo pellentesque ac lectus quis elit blandit fringilla a ut turpis. Does the Pope shit in the woods? Praesent felis ligula, malesuada.

JUST BECAUSE WE'RE BEREAVED DOESN'T MEAN WE'RE SAPS! Suscipit malesuada non, ultrices non. People forget that the brain is the biggest erogenous zone. Urna sed orci ipsum, placerat id condimentum. Eight-year-olds, Dude. Rutrum, rhoncus ac lorem aliquam placerat posuere neque, at dignissim. You might fool the fucks in the league office, but you don't fool Jesus! Magna ullamcorper in aliquam sagittis massa ac tortor. I have no choice but to tell these bums that they should do whatever is necessary to recover their money from you, Jeffrey Lebowski. Ultrices faucibus curabitur eu mi.

[Read more](http://www.lebowskiipsum.com/)